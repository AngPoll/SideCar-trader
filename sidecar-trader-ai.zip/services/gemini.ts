import { GoogleGenAI } from "@google/genai";
import { StockState, Trigger } from "../types";

export const getTradingAdvice = async (
  symbol: string, 
  currentState: StockState, 
  recentTriggers: Trigger[]
): Promise<string> => {
  // Create a fresh instance right before the call as per SDK guidelines
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const indicators = currentState.indicators;
  const trendBias = currentState.close > indicators.sma50 ? "BULLISH" : "BEARISH";
  const trigger = recentTriggers[0];
  
  const bbWidth = (indicators.bollinger.upper - indicators.bollinger.lower) / indicators.bollinger.middle;
  const volState = bbWidth > 0.04 ? "PANIC EXPANSION" : bbWidth > 0.02 ? "EXPANSION" : bbWidth < 0.012 ? "HYDRA SQUEEZE" : "NORMAL";

  const systemInstruction = `
    YOU ARE THE HYDRA v11.5 REAL-TIME EXECUTION ENGINE.
    YOUR MISSION: AUDIT TRADING SIGNALS FOR A 1% WAVE IGNITION.
    
    [STRICT THRESHOLDS]
    - TARGET GAIN: MINIMUM 1.0%
    - RISK TOLERANCE: MAXIMUM 0.4%
    - R/R RATIO: MUST BE 1:2.5 OR BETTER.
    
    [AUDIT PROTOCOL]
    1. ANALYZE if the current kinetic impulse (velocity) has the strength to carry price to the 1% target.
    2. REJECT signals if RSI is overextended (RSI > 70 for BUYS, < 30 for SELLS).
    3. VALIDATE trend alignment with SMA 50.
    4. Provide a verdict: [STRIKE NOW], [WAIT], or [DISREGARD].
  `;

  const userPrompt = `
    [LIVE TAPE]
    - SYMBOL: ${symbol}
    - PRICE: $${currentState.close.toFixed(2)}
    - VOLATILITY: ${volState}
    - TREND: ${trendBias}
    
    [SIGNAL DATA]
    - REASON: ${trigger?.reason}
    - ENTRY: $${trigger?.price.toFixed(2)}
    - GOAL (+1%): $${trigger?.targetPrice?.toFixed(2)}
    - STOP (-0.4%): $${trigger?.stopLoss?.toFixed(2)}
    - IMPULSE: ${trigger?.velocityAtEntry?.toFixed(4)}%
    
    Structure response:
    ### 🐋 WAVE CONVICTION ANALYSIS
    - **VERDICT**: [STRIKE NOW / WAIT / DISREGARD]
    - **PROBABILITY**: [0-100]%
    
    ### ⚡ EXECUTION
    - **PROTECTION**: $${trigger?.stopLoss?.toFixed(2)}
    
    ### 🔍 TACTICAL COLOR
    Brief 1-sentence logic.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: userPrompt,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.1,
        topP: 0.95
      }
    });

    return response.text || "Audit failed. Engine yielded empty response.";
  } catch (error: any) {
    const errorMsg = error?.message || "";
    console.error("AI Audit Error:", error);
    
    if (errorMsg.includes("Requested entity was not found") || errorMsg.includes("403") || errorMsg.includes("401")) {
      return "NEURAL_LINK_REQUIRED: The AI Strategist requires a valid Neural Link. Please select a paid API key using the 'Connect Neural Link' button in the header.";
    }
    
    if (errorMsg.includes("429") || errorMsg.includes("RESOURCE_EXHAUSTED")) {
      return "⚠️ **AI QUOTA EXHAUSTED**\n\nRate limit reached. Please wait or connect a higher-tier Neural Link.";
    }
    
    return "Error connecting to AI strategist. Check your internet connection or Neural Link status.";
  }
};